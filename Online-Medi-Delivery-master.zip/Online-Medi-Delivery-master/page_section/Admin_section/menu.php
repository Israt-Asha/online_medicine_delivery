
<div class="btn-group" style="margin-left:20%;margin-top:0px;margin-bottom:35px;text-align:center;">
                <button type="button" class="btn btn-secondary delir" name ="delr" value="Delr">Delivery Request</button>
                <button type="button" class="btn btn-secondary sgnuprq ">Signup Request</button>
                <button onclick="deliinfo()" type="button" class="btn btn-secondary delinfoad">Delivery Info</button>
                <button  type="button" class="btn btn-secondary sellerinfoad">sellerinfo</button>
                <button onclick=" Delmaninfo()" type="button" class="btn btn-secondary delmaninfoad">Delivery Man Info</button>
                <button onclick=" Home()" type="button" class="btn btn-secondary homead">Home</button>
</div>


