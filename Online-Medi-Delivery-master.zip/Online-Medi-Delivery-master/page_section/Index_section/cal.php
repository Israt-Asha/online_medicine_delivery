
<section class="coverage">
      <div class="container">
      <div class="cal">
        <div class ="header3">
          <p><b> Delivery charge calculator</b></p>
          <div class=" css-11rzb4k"></div>
        </div>
        <div class ="btn-radio">
        <div class="btn-group btn-group-toggle " data-toggle="buttons">
        
        <label class="btn  active btn-danger btn-lg rdo1">
            <input onclick="charge()" type="radio" name="options city" id="option1" autocomplete="off" checked vlalue="60"> Dhaka city
          </label>
         
      
        <label class="btn btn-danger btn-lg rdo2 ">
          <input onclick="charge()"  type="radio" name="options city" id="option2" autocomplete="off" vlalue="100"> Dhaka Subcity
          </label>
        
        
        <label class="btn btn-danger btn-lg rdo3">
            <input onclick="charge()" type="radio" name="options city" id="option3" autocomplete="off" vlalue="150"> Outside Dhaka
          </label>

      </div>
        </div>
        <div class="header5"><p><b> Select The Amount (Money) Of Your Drugs</b></p></div>
        
        <div class ="btn-radio2">
        <div class="btn-group btn-group-toggle " data-toggle="buttons">
        
        <label class="btn  active btn-danger btn-lg rdo1">
            <input onclick="charge()" type="radio" name="options" id="option1" autocomplete="off" checked vlalue="1"> Bellow 500
          </label>
         
      
        <label class="btn btn-danger btn-lg rdo2 ">
          <input onclick="charge()" type="radio" name="options" id="option2" autocomplete="off" vlalue="2"> 500 To 1000
          </label>
        
        
        <label class="btn btn-danger btn-lg rdo3">
            <input onclick="charge()" type="radio" name="options" id="option3" autocomplete="off" vlalue="3"> 1000 To 5000
          </label>
          <label class="btn btn-danger btn-lg rdo4">
            <input type="radio" name="options" id="option3" autocomplete="off" vlalue="4"> Above 5000
          </label>

      </div>
        </div>
        
      </div>
      </div>