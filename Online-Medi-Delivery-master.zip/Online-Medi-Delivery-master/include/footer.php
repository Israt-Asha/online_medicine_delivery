
<footer>
  <div class="coverage"style="background-color: lightslategray;">

 
    <div class="container" >
        <div class="footer-head">
        <div class="row r1">
        <div class="col">
          <div class="head7">
            <p><b>Important links</b></p>
            
          </div>
        </div>
        <div class="col">
          <div class="head7">
            <p><b>Contact</b></p>
          </div>
        </div>
        <div class="col">
        <div class="head7">
            <p><b>Address</b></p>
          </div>
        </div>
        <div class="col">
        <div class="head7">
            <p><b>About</b></p>
          </div>
        </div>
          
         
          </div>
        </div>
        <div class="footer-subhead7">
          <div class="row r1">
        <div class="col">
          <div class="sub-head7">
            <p><a href="#">privacy policy</a><br><a href="#">about us</a>
          <br><a href="#">coverage area</a></p>
          </div>
        </div>
        <div class="col">
          <div class="sub-head7">
            <p>01956-424568 <br>01861-670601 <br>shazib.shahriyar@gmail.com <br>ishratjahan@gmail.com</p>
          </div>
        </div>
        <div class="col">
        <div class="sub-head7">
            <p>12/A-road.no:3B-Sector:9 <br> Gulshan-2 1200 Bangladesh</p>
          </div>
        </div>
        <div class="col">
        <div class="sub-head7">
            <p>this is a demo project we could not impliment it properly
            for time shortge and some other lackege we will work further for
            better user experience </p>
          </div>
        </div>
      </div>
      </div>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
    <script src="js\app.js"></script>
    </footer>

    
      
    
   
    
</html>