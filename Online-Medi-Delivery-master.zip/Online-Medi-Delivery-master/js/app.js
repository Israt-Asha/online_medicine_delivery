
$(document).ready(function () {
   
    $(".trac").click(function () { 
       
        
        console.log("working");
        window.open("trac.php","self");
 
    });
});
$(document).ready(function () {
   
    $(".tracsel").click(function () { 
       
        
        console.log("working");
        window.open("seller_trac.php","self");
 
    });
});
$(document).ready(function () {
   
    $(".delinfo").click(function () { 
       
        
        console.log("working");
        window.open("deliveryinfoseller.php","self");
 
    });
});
$(document).ready(function () {
   
    $(".back").click(function () { 
       
        
        console.log("working");
        window.open("seller.php","self");
 
    });
});
$(document).ready(function () {
   
    $(".place_del_req").click(function () { 
       
        
        console.log("working");
        window.open("place_del_req.php","self");
 
    });
});

$(document).ready(function () {
   
    $(".pendelman").click(function () { 
       
        
        console.log("working");
        window.open("pendingdel_delman.php","self");
 
    });
});

$(document).ready(function () {
   
    $(".rundelman").click(function () { 
       
        
        console.log("working");
        window.open("running_del_delman.php","self");
 
    });
});
$(document).ready(function () {
   
    $(".backdelman").click(function () { 
       
        
        console.log("working");
        window.open("Deliveryman.php","self");
 
    });
});
$(document).ready(function () {
   
    $(".cng").click(function () { 
       
        
        console.log("working");
        window.open("login.php","");
 
    });
});
$(document).ready(function () {
   
    $(".delir").click(function () { 
       
        
        console.log("working");
        window.open("Del_info_req_Admin.php","self");
 
    });
});
$(document).ready(function () {
   
    $(".sgnuprq").click(function () { 
       
        
        console.log("working");
        window.open("signupreqadmin.php","self");
 
    });
});
$(document).ready(function () {
   
    $(".homead").click(function () { 
       
        
        console.log("working");
        window.open("admin.php","self");
 
    });
});

$(document).ready(function () {
   
    $(".delinfoad").click(function () { 
       
        
        console.log("working");
        window.open("del_info_admin.php","self");
 
    });
});
$(document).ready(function () {
   
    $(".delmaninfoad").click(function () { 
       
        
        console.log("working");
        window.open("Del_man_info_admin.php","self");
 
    });
});
$(document).ready(function () {
   
    $(".sellerinfoad").click(function () { 
       
        
        console.log("working");
        window.open("Sellerinfoad.php","self");
 
    });
});
$(document).ready(function () {
   
    $(".pendelreqseller").click(function () { 
       
        
        console.log("working");
        window.open("pendingdelreqseller.php","self");
 
    });
});
$(document).ready(function () {
   
    $(".trackindesk").click(function () { 
       
        
        console.log("working");
        window.open("trac.php","self");
 
    });
});
function logout()
{
   // alert("hello");
     session_destroy();
}




