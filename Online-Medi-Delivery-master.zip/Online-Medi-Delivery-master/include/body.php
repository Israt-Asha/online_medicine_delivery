<section >
      
      <div class="container body ">
      <div class="row">
  <div class="col-sm-3 card1">
    <div class="card"style="width: 18rem;">
    <img class="card-img-top" src="include\payment.jpg" alt="Card image cap">
      <div class="card-body">
        <h5 class="card-title">Payment the next day</h5>
        <p class="card-text">Payment is made directly through bank / bKash on the day after order delivery.</p>
        
      </div>
    </div>
  </div>
  <div class="col-sm-3 card2">
    <div class="card"style="width: 18rem;">
        <img class="card-img-top" src="include\cod.jpg" alt="Card image cap"> 
      <div class="card-body">
        <h5 class="card-title">0% COD charge</h5>
        <p class="card-text">There is no "cash on delivery" charge for delivery within Bangladesh.</p>
        
      </div>
    </div>
  </div>
  <div class="col-sm-3 card3">
    <div class="card"style="width: 18rem;">
        <img class="card-img-top" src="include\bdmap.jpg" alt="Card image cap"> 
      <div class="card-body">
        <h5 class="card-title">Nationwide delivery service</h5>
        <p class="card-text">Home delivery facility in 400+ police station areas of the country including Dhaka</p>
        
      </div>
    </div>
  </div>
</div>
      </div>
      <div class="container body ">
      <div class="row ">
  <div class="col-sm-3 card4">
    <div class="card"style="width: 18rem;">
    <img class="card-img-top" src="include\real time'.jpg" alt="Card image cap">
      <div class="card-body">
        <h5 class="card-title">Real time order tracking</h5>
        <p class="card-text">Real-time order tracking lets you know the latest updates on each order, anytime.</p>
        
      </div>
    </div>
  </div>
  <div class="col-sm-3 card5">
    <div class="card"style="width: 18rem;">
        <img class="card-img-top" src="include\fastdelivery.jpg" alt="Card image cap"> 
      <div class="card-body">
        <h5 class="card-title">Fast delivery</h5>
        <p class="card-text">We have 1,500 skilled deliverymen who complete deliveries nationwide in the fastest time.</p>
        
      </div>
    </div>
  </div>
  <div class="col-sm-3 card6">
    <div class="card"style="width: 18rem;">
        <img class="card-img-top" src="include\bikash.png" alt="Card image cap"> 
      <div class="card-body">
        <h5 class="card-title">BKASH payment facility</h5>
        <p class="card-text">For the convenience of delivery payment, the customer can now make delivery payment through cash on delivery and BKASH, right at the doorstep!</p>
        
      </div>
    </div>
  </div>
</div>
      </div>
</section>
