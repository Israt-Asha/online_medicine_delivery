</section>
    <section class="coverage">
      <div class ="css-011">
        <div class="header01">
          <p><b>We is providing home delivery service in 48 police stations in 64 districts of Bangladesh.</b> </p>
        </div>
        <div class="subheader1">Now wherever your customer is in the country, We will deliver the product to your doorstep!
        <div class=" css-11rzb4k"></div>
        </div>
       <!-- <div class="btnarea"><button type="button" class="btn btn-danger btn-lg btnsrc">search your area</button></div>!-->
        <div class="container areaname">
          <div class =" name">
        <div class="row r1">
        <div class="col">Barguna </div>
        <div class="col">Barisal</div>
        <div class="col">Bhola</div>
        <div class="col">Jhalokati</div>
      </div>
      <div class="row r2">
        <div class="col">Patuakhali</div>
        <div class="col">Pirojpur</div>
        <div class="col">Bandarban</div>
        <div class="col">Brahmanbaria   </div>
      </div>
      <div class="row r3">
        <div class="col">Chandpur   </div>
        <div class="col">Chittagong   </div>
        <div class="col">Comilla   </div>
        <div class="col">Cox's Bazar </div>
      </div>
      <div class="row r4">
        <div class="col">Feni   </div>
        <div class="col">Khagrachhari   </div>
        <div class="col">Lakshmipur   </div>
        <div class="col">Noakhali   </div>
      </div>
      <div class="row r5">
        <div class="col">Rangamati   </div>
        <div class="col">Dhaka   </div>
        <div class="col">Faridpur   </div>
        <div class="col">Gazipur   </div>
      </div>
      <div class="row r6">
        <div class="col">Gopalganj   </div>
        <div class="col">Kishoreganj   </div>
        <div class="col">Madaripur   </div>
        <div class="col">Manikganj   </div>
      </div>
      <div class="row r7">
        <div class="col">Munshiganj   </div>
        <div class="col">Narayanganj   </div>
        <div class="col">Narsingdi   </div>
        <div class="col">Rajbari   </div>
      </div>
      <div class="row r8">
        <div class="col">Shariatpur   </div>
        <div class="col">Tangail   </div>
        <div class="col">Bagerhat   </div>
        <div class="col">Chuadanga   </div>
      </div>
      <div class="row r9">
        <div class="col">Jessore   </div>
        <div class="col">Jhenaidah   </div>
        <div class="col">Khulna   </div>
        <div class="col">Kushtia   </div>
      </div>
      <div class="row r10">
        <div class="col">Magura   </div>
        <div class="col">Meherpur   </div>
        <div class="col">Narail   </div>
        <div class="col">Satkhira   </div>
      </div>
      <div class="row r11">
        <div class="col">Jamalpur   </div>
        <div class="col">Mymensingh   </div>
        <div class="col">Netrokona   </div>
        <div class="col">Sherpur   </div>
      </div>
      <div class="row r12">
        <div class="col">Bogra   </div>
        <div class="col">Joypurhat   </div>
        <div class="col">Naogaon   </div>
        <div class="col">Natore   </div>
      </div>
      <div class="row r13">
        <div class="col">  Chapai Nawabganj  </div>
        <div class="col">Pabna   </div>
        <div class="col">Rajshahi   </div>
        <div class="col">Sirajganj   </div>
      </div>
      <div class="row r14">
        <div class="col">Dinajpur   </div>
        <div class="col">Gaibandha   </div>
        <div class="col">Kurigram   </div>
        <div class="col">Lalmonirhat   </div>
      </div>
      <div class="row r15">
        <div class="col">Nilphamari   </div>
        <div class="col">Panchagarh   </div>
        <div class="col">Rangpur   </div>
        <div class="col">Thakurgaon   </div>
      </div>
      <div class="row 16">
        <div class="col">Habiganj   </div>
        <div class="col">Moulvibazar   </div>
        <div class="col">Sunamganj   </div>
        <div class="col">Sylhet   </div>
      </div>
      </div>
        </div>
        
      </div>
    </section>