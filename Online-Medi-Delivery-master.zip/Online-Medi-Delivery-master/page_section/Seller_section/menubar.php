
<div class="btn-group" style="margin-left:28%;margin-top:0px;margin-bottom:35px;text-align:center;">
                <button type="button" class="btn btn-secondary delinfo">Delivery InFo</button>
                <button type="button" class="btn btn-secondary place_del_req">Place Delivery Request</button>
                <button type="button" class="btn btn-secondary pendelreqseller">Pending Delivery Request</button>
                <button type="button" class="btn btn-secondary back">Home</button>
  </div>


            
            
