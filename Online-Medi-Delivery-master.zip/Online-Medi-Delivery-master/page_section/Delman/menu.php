<div class="btn-group" style="margin-left:40%;margin-top:0px;margin-bottom:35px;text-align:center;">
                <!--<button type="button" class="btn btn-secondary pendelman">Pending Delivery</button>!-->
                <button type="button" class="btn btn-secondary rundelman">Delivery INFO</button>
                <!--<button type="button" class="btn btn-secondary">Payment</button>!-->
                <button type="button" class="btn btn-secondary backdelman">Home</button>
 </div>